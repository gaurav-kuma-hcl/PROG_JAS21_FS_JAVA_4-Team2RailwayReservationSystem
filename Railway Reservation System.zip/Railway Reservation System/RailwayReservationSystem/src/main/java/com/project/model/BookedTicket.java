package com.project.model;

import java.util.Date;

import javax.persistence.*;

import com.sun.istack.NotNull;

import lombok.Data;


@Entity
@Table(name="bookedticket")
public class BookedTicket
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Serial_Number")
	private int serialNumber;
	
	@Column(name="BookedDate")
	private Date bookedDate;
	
	@Column(name="PName")
	private String pName;
	
	@Column(name="PAge")
	private String pAge;
	
	@Column(name="PAddress")
	private String pAddress;
	
	
	@Column(name="NumberOf_seats")
	private int numberOfSeats;

	
	public int getSerialNumber() {
		return serialNumber;
	}
    
	  @OneToOne(targetEntity=BookedTicket.class, cascade=CascadeType.ALL)
	  @JoinColumn(name="trainNumber", unique=true)
	  Train trainDetails;

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}


	public Date getBookedDate() {
		return bookedDate;
	}


	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}


	public String getpName() {
		return pName;
	}


	public void setpName(String pName) {
		this.pName = pName;
	}


	public String getpAge() {
		return pAge;
	}


	public void setpAge(String pAge) {
		this.pAge = pAge;
	}


	public String getpAddress() {
		return pAddress;
	}


	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}


	public int getNumberOfSeats() {
		return numberOfSeats;
	}


	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}


	public Train getTrainDetails() {
		return trainDetails;
	}


	public void setTrainDetails(Train trainDetails) {
		this.trainDetails = trainDetails;
	}


	


	@Override
	public String toString() {
		return "BookedTicket [serialNumber=" + serialNumber + ", bookedDate=" + bookedDate + ", pName=" + pName
				+ ", pAge=" + pAge + ", pAddress=" + pAddress + ", numberOfSeats=" + numberOfSeats + ", trainDetails="
				+ trainDetails + "]";
	}

	
}


