package com.project.model;

import javax.persistence.*;

import lombok.Data;


@Entity
@Table(name="train")
public class Train 
{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="Train_Number")
private int trainNumber;

@Column(name="Train_Name")
private String trainName;

@Column(name="Source")
private String source;

@Column(name="Destination")
private String destination;

@Column(name="Train_day")
private String trainDay;

//In table the datatype is Time here it is String
@Column(name="TrainTime")
private String trainTime;

public int getTrainNumber() {
	return trainNumber;
}

public void setTrainNumber(int trainNumber) {
	this.trainNumber = trainNumber;
}

public String getTrainName() {
	return trainName;
}

public void setTrainName(String trainName) {
	this.trainName = trainName;
}

public String getSource() {
	return source;
}

public void setSource(String source) {
	this.source = source;
}

public String getDestination() {
	return destination;
}

public void setDestination(String destination) {
	this.destination = destination;
}

public String getTrainDay() {
	return trainDay;
}

public void setTrainDay(String trainDay) {
	this.trainDay = trainDay;
}

public String getTrainTime() {
	return trainTime;
}

public void setTrainTime(String trainTime) {
	this.trainTime = trainTime;
}

@Override
public String toString() {
	return "Train [trainNumber=" + trainNumber + ", trainName=" + trainName + ", source=" + source + ", destination="
			+ destination + ", trainDay=" + trainDay + ", trainTime=" + trainTime + "]";
}

//@OneToOne
//(mappedBy="trainDetails", cascade=CascadeType.ALL)
//private BookedTicket bookedTicketDetails;


}
