package com.project.service;
import com.project.dao.BookedTicketDAO;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.BookedTicket;


@Service
public class BookedTicketService 
{
 @Autowired
 private BookedTicketDAO bookticketdao;
 

 public BookedTicket add(BookedTicket bt) 
	{
		return bookticketdao.save(bt);  
	}
 
 
 public void delete(int serialNumber)
	{
	 bookticketdao.deleteById(serialNumber);
	}
 
 public List<BookedTicket> getAll()
	{
		List<BookedTicket> pTicket = new ArrayList<BookedTicket>();
		Iterable<BookedTicket> it = bookticketdao.findAll();
		it.forEach(ticket -> {
			pTicket.add(ticket);
		});
		return pTicket;
 
 /*public BookedTicket getByTrainNumber(int trainNumber)
 {
		BookedTicket ticket = null;
		Optional<BookedTicket> opt = bookticketdao.findById(trainNumber);
		if(opt.isPresent())
		{
			ticket = opt.get();
		}
		return ticket;*/
	}
}
