export class Train {
    /*public trainNumber: number;
    public trainName: string;
    public source: string;
    public destination: string;
    public trainDay: string;
    public trainTime: string;*/

    constructor(public trainNumber: number,public trainName: string,public source: string,public destination: string,public trainDay: string,public trainTime: string)
    {
        
    } 
}
