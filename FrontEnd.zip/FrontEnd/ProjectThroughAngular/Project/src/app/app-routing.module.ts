import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { TrainListComponent } from './train-list/train-list.component';



const routes: Routes = [
{path:'home', component:HomeComponent},
{ path: 'about', component:AboutComponent },

{ path:'contact-us', component:ContactUsComponent},
{ path:'book-ticket', component:BookTicketComponent},
{path: 'train-list', component:TrainListComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
