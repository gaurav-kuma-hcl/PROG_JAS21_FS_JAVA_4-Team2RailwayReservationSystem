import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Train } from './train';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
@Injectable({
    providedIn: 'root'
  })
  
  export class TrainService 
  {
    trains: Train[];
    
    constructor(private _httpClient: HttpClient) 
    {
       
  
     }
    getAll(): Observable<Train[]>
    {
      console.log("getAll");
      let url ="http://localhost:8085//trains";
      return this._httpClient.get<Train[]>(url).pipe( map (response => response));
     }
  }


