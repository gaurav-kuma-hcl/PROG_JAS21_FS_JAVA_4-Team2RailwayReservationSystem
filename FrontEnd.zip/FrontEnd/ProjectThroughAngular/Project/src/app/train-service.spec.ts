import { TrainService } from './train-service';

describe('TrainService', () => {
  it('should create an instance', () => {
    expect(new TrainService()).toBeTruthy();
  });
});
