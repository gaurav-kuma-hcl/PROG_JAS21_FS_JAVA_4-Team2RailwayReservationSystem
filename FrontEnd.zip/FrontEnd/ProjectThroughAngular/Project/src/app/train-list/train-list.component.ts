import { Component, OnInit } from '@angular/core';
import { Train } from '../train';

import { TrainService } from '../train-service';

@Component({
  selector: 'app-train-list',
  templateUrl: './train-list.component.html',
  styleUrls: ['./train-list.component.css']
})   
export class TrainListComponent{
  
  train: Train[] = [];
  constructor(private service: TrainService) {
    this.service.getAll().subscribe(data => {
      this.train = data;
    });
  }
  
  ngOnInit() {
  }

}